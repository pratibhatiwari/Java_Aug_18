package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Department;
import com.example.repository.DepartmentJpaRepository;

@RestController
@RequestMapping("/department")
public class DepartmentController
{
	
	@Autowired
	private DepartmentJpaRepository departmentJpaRepository;
	
	@GetMapping(value="/all")
	public List<Department> findAll()
	{return departmentJpaRepository.findAll();
	}
	
	@GetMapping(value="/{name}")
	public Department findByName(@PathVariable final String name)
	{return departmentJpaRepository.findByName(name);
	}
	
	@PostMapping(value="/loadDeparment")
	public Department load(@RequestBody final Department department)
	{
		departmentJpaRepository.save(department);
		return departmentJpaRepository.findByName(department.getName());
	}
	{
		
	}

}